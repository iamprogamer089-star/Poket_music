package com.piro.pocketmusic

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.TimeUnit

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: Uri,
    val duration: Long
)

private val Ink = Color(0xFF101014)
private val Panel = Color(0xFF1C1C24)
private val Muted = Color(0xFFAAAAB5)
private val Accent = Color(0xFFFF4F87)

class MainActivity : ComponentActivity() {
    private var musicController by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) loadSongs() }

    private var songs by mutableStateOf<List<Song>>(emptyList())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else permissionLauncher.launch(permission)

        val sessionToken = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try { musicController = controllerFuture?.get() }
            catch (_: Exception) { musicController = null }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Ink, surface = Panel, primary = Accent,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) {
                PocketMusicScreen(
                    songs = songs,
                    player = musicController,
                    onRefresh = { loadSongs() }
                )
            }
        }
    }

    private fun loadSongs() {
        val list = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        contentResolver.query(collection, projection, selection, null, sort)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                list += Song(
                    id, cursor.getString(titleCol) ?: "Unknown title",
                    cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                    cursor.getString(albumCol) ?: "Unknown album",
                    Uri.withAppendedPath(collection, id.toString()),
                    cursor.getLong(durationCol)
                )
            }
        }
        songs = list
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

@Composable
private fun PocketMusicScreen(songs: List<Song>, player: Player?, onRefresh: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf("Songs") }
    var currentIndex by remember { mutableIntStateOf(-1) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var favourites by remember { mutableStateOf(setOf<Long>()) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentIndex = player?.currentMediaItemIndex ?: -1
            }
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                duration = player?.duration?.takeIf { it > 0 } ?: 0L
            }
        }
        player?.addListener(listener)
        onDispose { player?.removeListener(listener) }
    }

    LaunchedEffect(player, isPlaying) {
        while (true) {
            if (player != null) {
                position = player.currentPosition.coerceAtLeast(0)
                duration = player.duration.takeIf { it > 0 } ?: 0L
                currentIndex = player.currentMediaItemIndex
                isPlaying = player.isPlaying
            }
            kotlinx.coroutines.delay(500)
        }
    }

    val visibleSongs = songs.filter {
        (selectedTab != "Liked" || it.id in favourites) &&
        (it.title.contains(query, true) || it.artist.contains(query, true) || it.album.contains(query, true))
    }
    val currentSong = songs.getOrNull(currentIndex)

    Column(
        Modifier.fillMaxSize().background(Ink).statusBarsPadding().navigationBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(
                Brush.linearGradient(listOf(Accent, Color(0xFFFF9B61)))
            ), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("POCKET", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("YOUR MUSIC, YOUR WORLD", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, "Rescan music", tint = Color.White) }
        }

        Text("Made for your", color = Muted, fontSize = 14.sp)
        Text("every moment.", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))

        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search songs, artists, albums…", color = Muted) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Muted) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF34343E),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                cursorColor = Accent
            )
        )
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("Songs", "Liked").forEach { tab ->
                FilterChip(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    label = { Text(tab) },
                    leadingIcon = if (tab == "Liked") ({ Icon(Icons.Default.Favorite, null, Modifier.size(16.dp)) }) else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Accent, selectedLabelColor = Color.White,
                        labelColor = Muted
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true, selected = selectedTab == tab,
                        borderColor = Color(0xFF383842), selectedBorderColor = Accent
                    )
                )
            }
            Spacer(Modifier.weight(1f))
            Text("${visibleSongs.size} TRACKS", color = Muted, fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterVertically))
        }

        if (songs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.LibraryMusic, null, tint = Accent, modifier = Modifier.size(54.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Your library is waiting", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Add audio files to your phone, then tap refresh.", color = Muted, fontSize = 12.sp)
                }
            }
        } else if (visibleSongs.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No matching tracks", color = Muted)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                itemsIndexed(visibleSongs, key = { _, song -> song.id }) { _, song ->
                    val realIndex = songs.indexOfFirst { it.id == song.id }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                            .background(if (realIndex == currentIndex) Color(0xFF30212B) else Panel)
                            .clickable {
                                if (player != null) {
                                    val mediaItems = songs.map { item ->
                                        MediaItem.Builder().setUri(item.uri).setMediaMetadata(
                                            MediaMetadata.Builder().setTitle(item.title).setArtist(item.artist).setAlbumTitle(item.album).build()
                                        ).build()
                                    }
                                    player.setMediaItems(mediaItems, realIndex, 0L)
                                    player.prepare()
                                    player.play()
                                }
                            }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF56314C), Color(0xFF242A43)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, null, tint = Color(0xFFFFB5CC), modifier = Modifier.size(23.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(song.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = {
                            favourites = if (song.id in favourites) favourites - song.id else favourites + song.id
                        }) {
                            Icon(Icons.Default.Favorite, null, tint = if (song.id in favourites) Accent else Color(0xFF777783), modifier = Modifier.size(19.dp))
                        }
                        Text(formatTime(song.duration), color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }

        AnimatedVisibility(visible = currentSong != null) {
            Column(
                Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFF28202A)).padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(
                        Brush.linearGradient(listOf(Accent, Color(0xFF6A4C93)))
                    ), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.GraphicEq, null, tint = Color.White, modifier = Modifier.size(25.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(currentSong?.title ?: "", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(currentSong?.artist ?: "", color = Muted, fontSize = 12.sp)
                    }
                    IconButton(onClick = {
                        currentSong?.let { song ->
                            favourites = if (song.id in favourites) favourites - song.id else favourites + song.id
                        }
                    }) {
                        Icon(Icons.Default.Favorite, null, tint = if (currentSong?.id in favourites) Accent else Muted)
                    }
                }
                Slider(
                    value = if (duration > 0) position.coerceAtMost(duration).toFloat() / duration else 0f,
                    onValueChange = { fraction -> player?.seekTo((fraction * duration).toLong()) },
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Color(0xFF51414C)),
                    modifier = Modifier.height(30.dp)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(formatTime(position), color = Muted, fontSize = 10.sp)
                    Text(formatTime(duration), color = Muted, fontSize = 10.sp)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shuffle = !shuffle; player?.shuffleModeEnabled = shuffle }) {
                        Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Accent else Muted)
                    }
                    IconButton(onClick = { player?.seekToPreviousMediaItem() }) {
                        Icon(Icons.Default.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    IconButton(
                        onClick = { if (player?.isPlaying == true) player.pause() else player?.play() },
                        modifier = Modifier.size(54.dp).clip(CircleShape).background(Accent)
                    ) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = { player?.seekToNextMediaItem() }) {
                        Icon(Icons.Default.SkipNext, null, tint = Color.White, modifier = Modifier.size(32.dp))
                    }
                    IconButton(onClick = {
                        repeat = when (repeat) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        player?.repeatMode = repeat
                    }) {
                        Icon(Icons.Default.Repeat, null, tint = if (repeat == Player.REPEAT_MODE_OFF) Muted else Accent)
                    }
                }
            }
        }
        Text("LOCAL LIBRARY  •  OFFLINE BY DESIGN", color = Color(0xFF777783), fontSize = 9.sp,
            letterSpacing = 1.2.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp))
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "0:00"
    val minutes = TimeUnit.MILLISECONDS.toMinutes(ms)
    val seconds = TimeUnit.MILLISECONDS.toSeconds(ms) % 60
    return "%d:%02d".format(minutes, seconds)
}
