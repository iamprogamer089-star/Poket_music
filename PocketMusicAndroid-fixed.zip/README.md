# Pocket Music (Android)

A native Android local-audio player with a dark, phone-first interface.

## Features
- Scans audio indexed by Android MediaStore
- Search by song, artist, or album
- Play/pause, previous/next, seek, shuffle, repeat
- Like/unlike tracks (session-only in this starter version)
- Media3 playback service with media-session notification/lock-screen controls
- Offline local playback; no streaming catalogue or account required

## Build an APK
1. Install **Android Studio** on a computer.
2. Open this `PocketMusicAndroid` folder in Android Studio.
3. Let Gradle sync. Use JDK 17.
4. Connect your Android phone with USB debugging enabled, or choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on your phone.
6. On first launch, allow the music/audio permission.

## Notes
- This repository contains the Android source project, not a precompiled APK.
- The app targets Android 15 (API 35), supports Android 6.0+ at the code level.
- Android 13+ uses `READ_MEDIA_AUDIO`; older versions use `READ_EXTERNAL_STORAGE`.
- The media session service supplies notification and lock-screen transport controls.
- Album artwork extraction, persistent playlists/favourites, folder browsing, and an in-app equalizer are good next upgrades.
- If Android Studio reports a Gradle/AGP compatibility prompt, accept the recommended Gradle wrapper update.
